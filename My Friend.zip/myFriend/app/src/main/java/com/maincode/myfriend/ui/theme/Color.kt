package com.maincode.myfriend.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFBCE0F0)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color( 0xFF6F35A5)
val Pink40 = Color(0xFFE0C2C0)


val DecentRed = Color(0xFFC1E1C1)
val DecentGreen = Color(0xFFC1E1C1)
val DecentBlue = Color( 0xFF966FD6)
val BlueLight = Color(0xFFAEC6CF)

//sealed class ThemeColors(
//    val background:Color,
//    val surface:Color,
//    val primary:Color,
//    val text:Color
//){
//    object Dark : ThemeColors(
//        background = Color(0XFFFFFFFF),
//        surface = Color(0XFFFFFFFF),
//        primary = Color(0XFF000000),
//        text = Color(0XFF000000)
//    )
//    object Light : ThemeColors(
//        background = Color(0XFF000000),
//        surface = Color(0XFF000000),
//        primary = Color(0XFFFFFFFF),
//        text = Color(0XFFFFFFFF)
//    )
//}